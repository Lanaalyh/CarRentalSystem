package datastructureproject;

    public interface Payment {

    public static final double INITAIL_FEE = 0.15;

    public abstract double calculateAmount();
}